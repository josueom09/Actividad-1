#!/usr/bin/env python3
"""Genera el PDF de entrega de la Actividad 4 con el formato de los informes del curso:
portada con logo, «EJERCICIO N», código fuente, diagrama de objetos, diagrama de clases y enlace al repositorio.
Además incluye lo que pide la hoja de la actividad: imagen de la interfaz y diagrama de casos de uso.

Uso (desde la raíz del proyecto):
  python3 tools/generar_informe.py --usuario josueom09 --repo actividad-1 --carpeta "ACTIVIDAD 4" \
      --estudiante "Nombre Apellido" --salida Informe_Actividad4.pdf
"""
import argparse
import os

from PIL import Image as PILImage, ImageDraw, ImageFont
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import cm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import Image, PageBreak, Paragraph, Preformatted, SimpleDocTemplate, Spacer

FUENTES = "/usr/share/fonts/truetype/liberation/"
CAPTURAS, DIAGRAMAS, LOGO, TEMP = "docs/capturas", "docs/diagramas", "docs/recursos/logo_unal.png", "build_informe"

# Liberation Sans es el equivalente métrico de Arial (la letra del informe de referencia)
pdfmetrics.registerFont(TTFont("LS", FUENTES + "LiberationSans-Regular.ttf"))
pdfmetrics.registerFont(TTFont("LS-B", FUENTES + "LiberationSans-Bold.ttf"))
pdfmetrics.registerFont(TTFont("LS-I", FUENTES + "LiberationSans-Italic.ttf"))
pdfmetrics.registerFont(TTFont("LS-BI", FUENTES + "LiberationSans-BoldItalic.ttf"))
pdfmetrics.registerFontFamily("LS", normal="LS", bold="LS-B", italic="LS-I", boldItalic="LS-BI")

PORTADA = ParagraphStyle("portada", fontName="LS-B", fontSize=13, leading=17, alignment=TA_CENTER, spaceAfter=1)
EJERCICIO = ParagraphStyle("ejercicio", fontName="LS-B", fontSize=10.5, leading=14, alignment=TA_CENTER,
                           spaceBefore=16, spaceAfter=12)
CODIGO = ParagraphStyle("codigo", fontName="LS", fontSize=9.4, leading=11.5)
TEXTO = ParagraphStyle("texto", fontName="LS", fontSize=11, leading=15, spaceBefore=14)

# Código fuente de cada ejercicio: las clases del ejercicio y su ventana
EJERCICIOS = [
    dict(n=1, codigo=["src/excepciones/PruebaExcepciones.java", "src/gui/PanelPruebaExcepciones.java"],
         titulo="Ejercicio 1 – Prueba de excepciones", capturas=["ej1_ejecucion"]),
    dict(n=2, codigo=["src/excepciones/Vendedor.java", "src/gui/PanelVendedor.java"],
         titulo="Ejercicio 2 – Vendedor", capturas=["ej2_error", "ej2_correcto"]),
    dict(n=3, codigo=["src/excepciones/CalculosNumericos.java", "src/gui/PanelCalculos.java"],
         titulo="Ejercicio 3 – Cálculos numéricos", capturas=["ej3_correcto", "ej3_errores"]),
    dict(n=4, codigo=["src/excepciones/EquipoMaratonProgramacion.java", "src/excepciones/Programador.java",
                      "src/gui/PanelEquipoMaraton.java"],
         titulo="Ejercicio 4 – Equipo de maratón de programación", capturas=["ej4_error_digitos", "ej4_equipo_completo"]),
    dict(n=5, codigo=["src/archivos/LeerArchivo.java", "src/gui/PanelLeerArchivo.java"],
         titulo="Ejercicio 5 – Lectura de archivos", capturas=["ej5_correcto", "ej5_error"]),
]


def codigo_fuente(rutas):
    """Une el código de varios archivos (sin cambios) en un solo bloque."""
    partes = []
    for ruta in rutas:
        with open(ruta, encoding="utf-8") as f:
            lineas = [l for l in f.read().replace("\t", "    ").split("\n") if not l.startswith("package ")]
            partes.append("\n".join(lineas).strip("\n"))
    return Preformatted("\n\n".join(partes), CODIGO, maxLineLength=94, splitChars=" ")


def enmarcar(origen, titulo, destino):
    """Agrega la barra de título de una ventana a la captura."""
    im = PILImage.open(origen).convert("RGB")
    barra, borde = 64, 3
    lienzo = PILImage.new("RGB", (im.width + 2 * borde, im.height + barra + 2 * borde), "#7C8288")
    d = ImageDraw.Draw(lienzo)
    d.rectangle([borde, borde, lienzo.width - borde, barra + borde], fill="#ECECEE")
    d.text((24, borde + 16), titulo, fill="#2B2B2B", font=ImageFont.truetype(FUENTES + "LiberationSans-Regular.ttf", 28))
    for i, c in enumerate(["#9AA0A6", "#9AA0A6", "#D9534F"]):
        cx = lienzo.width - 40 - i * 46
        d.ellipse([cx - 13, borde + 19, cx + 13, borde + 45], fill=c)
    lienzo.paste(im, (borde, barra + borde))
    lienzo.save(destino)
    return destino


def imagen(ruta, ancho_max, alto_max):
    with PILImage.open(ruta) as im:
        w, h = im.size
    escala = min(ancho_max / w, alto_max / h)
    img = Image(ruta, width=w * escala, height=h * escala)
    img.hAlign = "CENTER"
    return img


def construir(args):
    os.makedirs(TEMP, exist_ok=True)
    base = f"https://github.com/{args.usuario}/{args.repo}"
    enlace = base + (f"/tree/main/{args.carpeta.replace(' ', '%20')}" if args.carpeta else "")
    historia = []

    # Portada: logo y datos, y el ejercicio 1 empieza en la misma página (como en el informe de referencia)
    logo = PILImage.open(LOGO)
    ancho = 7.4 * cm
    historia += [Spacer(1, 2.3 * cm), Image(LOGO, width=ancho, height=ancho * logo.height / logo.width),
                 Spacer(1, 1.5 * cm),
                 Paragraph("Programación Orientada a Objetos 2026-2S", PORTADA),
                 Paragraph("Docente: Walter Hugo Arboleda Mazo", PORTADA),
                 Paragraph(args.estudiante or "[Nombre completo del estudiante]", PORTADA),
                 Paragraph("Actividad 4", PORTADA), Spacer(1, 1.1 * cm)]

    for e in EJERCICIOS:
        historia += [Paragraph(f"EJERCICIO {e['n']}", EJERCICIO), codigo_fuente(e["codigo"]), Spacer(1, 0.7 * cm)]
        for nombre in e["capturas"]:   # imagen de la interfaz (la pide la hoja de la actividad)
            ruta = enmarcar(f"{CAPTURAS}/{nombre}.png", e["titulo"], f"{TEMP}/{nombre}.png")
            historia += [imagen(ruta, 12.5 * cm, 9.0 * cm), Spacer(1, 0.4 * cm)]
        historia += [Spacer(1, 0.3 * cm), imagen(f"{DIAGRAMAS}/objetos_ej{e['n']}.png", 15.5 * cm, 9.0 * cm),
                     Spacer(1, 0.8 * cm),
                     imagen(f"{DIAGRAMAS}/clases_ej{e['n']}.png", 15.5 * cm, 16.5 * cm if e["n"] == 4 else 13.0 * cm),
                     Spacer(1, 0.8 * cm), imagen(f"{DIAGRAMAS}/casos_ej{e['n']}.png", 15.5 * cm, 10.0 * cm)]

    # Cierre: enlace al repositorio, igual que en el informe de referencia
    historia += [Paragraph(f'link del repositorio : <link href="{enlace}" color="#9B5C8F"><u>{enlace}</u></link>', TEXTO)]

    doc = SimpleDocTemplate(args.salida, pagesize=letter, leftMargin=2.6 * cm, rightMargin=2.2 * cm,
                            topMargin=2.0 * cm, bottomMargin=2.0 * cm,
                            title="Actividad 4 – Programación Orientada a Objetos 2026-2S",
                            author=args.estudiante or "Estudiante")
    doc.build(historia)
    print("PDF generado:", args.salida)


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--usuario", default="josueom09")
    p.add_argument("--repo", default="actividad-1")
    p.add_argument("--carpeta", default="")
    p.add_argument("--estudiante", default="")
    p.add_argument("--salida", default="Informe_Actividad4.pdf")
    construir(p.parse_args())
