#!/usr/bin/env python3
"""Genera los diagramas UML (clases y casos de uso) de la Actividad 4.

Uso (desde la raíz del proyecto):  python3 tools/generar_diagramas.py
Requiere: graphviz (comando `dot`) y matplotlib.
"""
import math
import os
import subprocess
import textwrap
from html import escape

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Ellipse, Rectangle, Circle

SALIDA = os.path.join("docs", "diagramas")
os.makedirs(SALIDA, exist_ok=True)
FUENTE = "Liberation Sans"  # equivalente métrico de Arial

# ──────────────────────────── Diagramas de clases ────────────────────────────

def clase(nombre, atributos=(), metodos=(), estereotipo=None, fondo="#FFFFFF", cabecera="#FFFFFF"):
    """Devuelve la etiqueta HTML de dot para una clase UML.

    Cada atributo/método es un texto o una tupla (texto, True) si es estático
    (se subraya, como pide UML).
    """
    def fila(item):
        texto, estatico = (item, False) if isinstance(item, str) else item
        if texto[:2] in ("+ ", "- "):
            texto = texto[0] + texto[2:]
        texto = escape(texto)
        if estatico:
            texto = f"<U>{texto}</U>"
        return f'<TR><TD ALIGN="LEFT" BALIGN="LEFT">{texto}</TD></TR>'

    def bloque(items):
        return "".join(fila(i) for i in items) if items else '<TR><TD> </TD></TR>'

    est = f'<TR><TD><FONT POINT-SIZE="9">{escape("«" + estereotipo + "»")}</FONT></TD></TR>' if estereotipo else ""
    return (f'<<TABLE BORDER="1" CELLBORDER="0" CELLSPACING="0" CELLPADDING="3" BGCOLOR="{fondo}">'
            f'<TR><TD BGCOLOR="{cabecera}"><TABLE BORDER="0" CELLBORDER="0" CELLSPACING="0">{est}'
            f'<TR><TD><B>{escape(nombre)}</B></TD></TR></TABLE></TD></TR>'
            f'<HR/>{bloque(atributos)}<HR/>{bloque(metodos)}</TABLE>>')


def marco_de(archivo):
    n = archivo.split("_ej")[-1]
    return f"Actividad 4 Ejercicio {n}" if n.isdigit() else "Actividad 4 – Vista general"


def dibujar_clases(archivo, titulo, nodos, aristas, clusters=None, rankdir="TB", extra="", enlaces_sin_flecha=False):
    """nodos: {id: etiqueta_html}; aristas: lista de tuplas (origen, destino, atributos_dot).
    Todos los nodos van dentro de un marco con el título de la actividad (estilo de los diagramas del curso)."""
    lineas = [
        "digraph G {",
        f'  graph [rankdir={rankdir}, fontname="{FUENTE}", nodesep=0.55, ranksep=0.8, pad=0.25, dpi=150, '
        f'bgcolor=white, compound=true, {extra}];',
        f'  node [shape=plain, fontname="{FUENTE}", fontsize=10];',
        f'  edge [fontname="{FUENTE}", fontsize=9];',
    ]
    con_marco = archivo.startswith("clases")
    if con_marco:
        lineas.append(f'  subgraph cluster_marco {{ label=<<B>{escape(marco_de(archivo))}</B>>; labeljust=c; labelloc=t; '
                      f'fontname="{FUENTE}"; fontsize=12; style=solid; color="#333333"; penwidth=1.3; margin=22;')
    for n, etiqueta in nodos.items():
        lineas.append(f"    {n} [label={etiqueta}];")
    if con_marco:
        lineas.append("  }")
    for origen, destino, attrs in aristas:
        lineas.append(f"  {origen} -> {destino} [{attrs}];")
    lineas.append("}")
    ruta_dot = os.path.join(SALIDA, archivo + ".dot")
    with open(ruta_dot, "w", encoding="utf-8") as f:
        f.write("\n".join(lineas))
    subprocess.run(["dot", "-Tpng", ruta_dot, "-o", os.path.join(SALIDA, archivo + ".png")], check=True)
    os.remove(ruta_dot)
    print("diagrama", archivo)


def objeto(nombre, clase_, atributos=()):
    """Etiqueta HTML de un objeto UML: «nombre: Clase» subrayado y atributos con su valor."""
    cab = f'<TR><TD><B><U>{escape(nombre + ": " + clase_)}</U></B></TD></TR>'
    if atributos:
        filas = "".join(f'<TR><TD ALIGN="LEFT" BALIGN="LEFT">{escape("+" + a)}</TD></TR>' for a in atributos)
        return (f'<<TABLE BORDER="1" CELLBORDER="0" CELLSPACING="0" CELLPADDING="3">{cab}<HR/>{filas}</TABLE>>')
    return f'<<TABLE BORDER="1" CELLBORDER="0" CELLSPACING="0" CELLPADDING="4">{cab}</TABLE>>'


ENLACE = 'arrowhead=none'


def diagramas_de_objetos():
    EXC = '"Ejercicio'
    dibujar_clases("objetos_ej1", "", {
        "v": objeto("ventana1", "Ventana", ['titulo = "Ejercicio 1 – Prueba de excepciones"', "cierre = DISPOSE_ON_CLOSE"]),
        "p": objeto("panel1", "PanelPruebaExcepciones", ['txtSalida = "Ingresando al primer try…"',
                                                          'txtExplicacion = "Primer bloque try…"']),
    }, [("v", "p", ENLACE + ', label="contenido"')], rankdir="LR")

    dibujar_clases("objetos_ej2", "", {
        "v": objeto("ventana2", "Ventana", ['titulo = "Ejercicio 2 – Vendedor"', "cierre = DISPOSE_ON_CLOSE"]),
        "p": objeto("panel2", "PanelVendedor", ['txtNombre = "María"', 'txtApellidos = "López"', 'txtEdad = "30"',
                                                'lblEstado = "Vendedor creado correctamente."']),
        "a": objeto("vendedor1", "Vendedor", ['nombre = "María"', 'apellidos = "López"', "edad = 30"]),
        "b": objeto("vendedor2", "Vendedor", ['nombre = "Carlos"', 'apellidos = "Gómez"', "edad = 45"]),
    }, [("v", "p", ENLACE + ', label="contenido"'), ("p", "a", ENLACE + ', label="crea"'),
        ("p", "b", ENLACE + ', label="crea"')], rankdir="LR")

    dibujar_clases("objetos_ej3", "", {
        "v": objeto("ventana3", "Ventana", ['titulo = "Ejercicio 3 – Cálculos numéricos"', "cierre = DISPOSE_ON_CLOSE"]),
        "p": objeto("panel3", "PanelCalculos", ['txtValor = "25"', 'txtSalida = "Logaritmo neperiano (25) = 3,218876…"']),
        "l": objeto("CO", "Locale", ['language = "es"', 'country = "CO"']),
    }, [("v", "p", ENLACE + ', label="contenido"'), ("p", "l", ENLACE + ', label="formato"')], rankdir="LR")

    dibujar_clases("objetos_ej4", "", {
        "v": objeto("ventana4", "Ventana", ['titulo = "Ejercicio 4 – Equipo de maratón…"', "cierre = DISPOSE_ON_CLOSE"]),
        "p": objeto("panel4", "PanelEquipoMaraton", ['txtEquipo = "EquipoUNAL"', 'txtUniversidad = "Universidad Nacional de Colombia"',
                                                      'txtLenguaje = "Java"', 'lblContador = "Integrantes: 3/3 · equipo completo"']),
        "e": objeto("equipo1", "EquipoMaratonProgramacion", ['nombreEquipo = "EquipoUNAL"',
                                                             'universidad = "Universidad Nacional de Colombia"',
                                                             'lenguajeProgramacion = "Java"', "tamanoEquipo = 3"]),
        "g1": objeto("prog1", "Programador", ['nombre = "Pedro"', 'apellidos = "Pérez"']),
        "g2": objeto("prog2", "Programador", ['nombre = "Pablo"', 'apellidos = "Gómez"']),
        "g3": objeto("prog3", "Programador", ['nombre = "Ana"', 'apellidos = "Ruiz"']),
    }, [("v", "p", ENLACE + ', label="contenido"'), ("p", "e", ENLACE + ', label="equipo"'),
        ("e", "g1", ENLACE + ', label="programadores[0]"'), ("e", "g2", ENLACE + ', label="programadores[1]"'),
        ("e", "g3", ENLACE + ', label="programadores[2]"')], rankdir="TB")

    dibujar_clases("objetos_ej5", "", {
        "v": objeto("ventana5", "Ventana", ['titulo = "Ejercicio 5 – Lectura de archivos"', "cierre = DISPOSE_ON_CLOSE"]),
        "p": objeto("panel5", "PanelLeerArchivo", ['txtRuta = "prueba.txt"', 'lblEstado = "Archivo leído correctamente (5 líneas)."']),
        "b": objeto("filtro", "BufferedReader"),
        "i": objeto("conversor", "InputStreamReader", ["charset = UTF-8"]),
        "f": objeto("archivo", "FileInputStream", ['nombreArchivo = "prueba.txt"']),
    }, [("v", "p", ENLACE + ', label="contenido"'), ("p", "b", ENLACE + ', label="lee con"'),
        ("b", "i", ENLACE), ("i", "f", ENLACE)], rankdir="TB")


USO = 'style=dashed, arrowhead=vee, label="«use»"'
CREA = 'style=dashed, arrowhead=vee, label="«create»"'
LANZA = 'style=dashed, arrowhead=vee, label="«throws»"'
CAPTURA = 'style=dashed, arrowhead=vee, label="«catch»"'
HERENCIA = 'arrowhead=empty'
JAVA = dict(fondo="#F6F6F6", cabecera="#E8E8E8")


ASOC = 'arrowhead=none, taillabel="1", headlabel="1", labeldistance=1.9, labelfontsize=9'


def diagramas_de_clases():
    """Diagramas de clases en el estilo de los ejemplos del curso: solo clases del proyecto."""
    dibujar_clases("clases_ej1", "", {
        "panel": clase("PanelPruebaExcepciones", [
            "- txtSalida: JTextArea", "- txtExplicacion: JTextArea"], [
            "+ PanelPruebaExcepciones()", "- ejecutar(): void"]),
        "prueba": clase("PruebaExcepciones", [], [
            "- PruebaExcepciones()", ("+ ejecutar(Consumer<String> salida): void", True)]),
    }, [("panel", "prueba", ASOC)])

    dibujar_clases("clases_ej2", "", {
        "panel": clase("PanelVendedor", [
            "- txtNombre: JTextField", "- txtApellidos: JTextField", "- txtEdad: JTextField",
            "- lblEstado: JLabel", "- txtSalida: JTextArea"], [
            "+ PanelVendedor()", "- crearVendedor(): void", "- limpiar(): void"]),
        "vendedor": clase("Vendedor", [
            "- nombre: String", "- apellidos: String", "- edad: int"], [
            "+ Vendedor(String nombre, String apellidos)", "+ verificarEdad(int edad): void",
            "+ imprimir(): String", "+ getNombre(): String", "+ getApellidos(): String", "+ getEdad(): int"]),
    }, [("panel", "vendedor", ASOC)])

    dibujar_clases("clases_ej3", "", {
        "panel": clase("PanelCalculos", [
            "- txtValor: JTextField", "- txtSalida: JTextArea"], [
            "+ PanelCalculos()", "- calcular(boolean logaritmo, boolean raiz): void",
            "- ejecutar(String nombre, DoubleUnaryOperator operacion, String texto): String"]),
        "calc": clase("CalculosNumericos", [], [
            "- CalculosNumericos()",
            ("+ calcularLogaritmoNeperiano(double valor): double", True),
            ("+ calcularRaizCuadrada(double valor): double", True),
            ("+ leerValor(String texto): double", True)]),
    }, [("panel", "calc", ASOC)])

    dibujar_clases("clases_ej4", "", {
        "panel": clase("PanelEquipoMaraton", [
            "- txtEquipo: JTextField", "- txtUniversidad: JTextField", "- txtLenguaje: JTextField",
            "- txtNombre: JTextField", "- txtApellidos: JTextField",
            "- modeloTabla: DefaultTableModel", "- equipo: EquipoMaratonProgramacion"], [
            "+ PanelEquipoMaraton()", "- crearEquipo(): void", "- anadirProgramador(): void",
            "- actualizarContador(): void", "- nuevoEquipo(): void"]),
        "equipo": clase("EquipoMaratonProgramacion", [
            "- nombreEquipo: String", "- universidad: String", "- lenguajeProgramacion: String",
            "- programadores: Programador[]", "- tamanoEquipo: int"], [
            "+ EquipoMaratonProgramacion(String nombreEquipo, String universidad,", "     String lenguajeProgramacion)",
            "+ estaLleno(): boolean", "+ tieneMinimoIntegrantes(): boolean",
            "+ anadir(Programador programador): void",
            ("+ validarCampo(String etiqueta, String campo): void", True),
            "+ getProgramador(int i): Programador"]),
        "prog": clase("Programador", ["- nombre: String", "- apellidos: String"], [
            "+ Programador(String nombre, String apellidos)", "+ getNombre(): String", "+ getApellidos(): String"]),
    }, [("panel", "equipo", ASOC),
        ("equipo", "prog", 'arrowhead=none, taillabel="1", headlabel="0..3", labeldistance=2.0, labelfontsize=9')], rankdir="LR")

    dibujar_clases("clases_ej5", "", {
        "panel": clase("PanelLeerArchivo", [
            "- txtRuta: JTextField", "- lblEstado: JLabel", "- txtSalida: JTextArea"], [
            "+ PanelLeerArchivo()", "- examinar(): void", "- leer(): void"]),
        "leer": clase("LeerArchivo", [], [
            "- LeerArchivo()", ("+ leer(String nombreArchivo): String", True)]),
    }, [("panel", "leer", ASOC)])


# ──────────────────────────── Diagramas de casos de uso ──────────────────────

A_ELIPSE, B_ELIPSE = 15.0, 5.8   # semiejes (en unidades de datos) de cada caso de uso


def punto_en_elipse(centro, hacia):
    """Punto del borde de la elipse (con centro `centro`) en dirección a `hacia`."""
    dx, dy = hacia[0] - centro[0], hacia[1] - centro[1]
    t = 1.0 / math.sqrt((dx / A_ELIPSE) ** 2 + (dy / B_ELIPSE) ** 2)
    return centro[0] + dx * t, centro[1] + dy * t


def segmento_cruza(p1, p2, nodos, ignorar):
    """Devuelve los casos de uso (distintos de `ignorar`) que atraviesa el segmento p1-p2."""
    cruzados = []
    for nid, (x, y, _) in nodos.items():
        if nid in ignorar:
            continue
        for k in range(1, 60):
            t = k / 60
            px, py = p1[0] + (p2[0] - p1[0]) * t, p1[1] + (p2[1] - p1[1]) * t
            if ((px - x) / (A_ELIPSE - 0.3)) ** 2 + ((py - y) / (B_ELIPSE - 0.3)) ** 2 < 1:
                cruzados.append(nid)
                break
    return cruzados


def casos_de_uso(archivo, titulo, sistema, nodos, con_actor, relaciones):
    """nodos: {id: (x, y, texto)}; con_actor: ids asociados al actor;
    relaciones: lista de (origen, destino, 'include' | 'extend')."""
    fig, ax = plt.subplots(figsize=(10, 5.9), dpi=180)
    fig.subplots_adjust(left=0.01, right=0.99, top=0.93, bottom=0.01)
    ax.set_xlim(0, 130)
    ax.set_ylim(0, 100)
    ax.axis("off")
    ax.set_title(titulo, fontsize=12, fontname=FUENTE, pad=8)

    # Límite del sistema
    ax.add_patch(Rectangle((24, 2), 104, 94, fill=False, lw=1.6, ec="#333333"))
    ax.text(26, 92.5, sistema, fontsize=10, fontweight="bold", va="center", fontname=FUENTE)

    for nid, (x, y, texto) in nodos.items():
        secundario = nid.startswith("s")
        ax.add_patch(Ellipse((x, y), 2 * A_ELIPSE, 2 * B_ELIPSE, zorder=3, lw=1.4, ec="#1B6B52",
                             fc="#FFF6DD" if secundario else "#E4F2EC"))
        ax.text(x, y, "\n".join(textwrap.wrap(texto, 27)), ha="center", va="center",
                fontsize=8.2, zorder=4, fontname=FUENTE)

    # Actor
    ax_x, ax_y = 8, 50
    ax.add_patch(Circle((ax_x, ax_y + 9), 2.6, fill=False, lw=1.8, ec="#222222"))
    ax.plot([ax_x, ax_x], [ax_y + 6.4, ax_y - 4], color="#222222", lw=1.8)
    ax.plot([ax_x - 5, ax_x + 5], [ax_y + 3, ax_y + 3], color="#222222", lw=1.8)
    ax.plot([ax_x, ax_x - 4.5], [ax_y - 4, ax_y - 12], color="#222222", lw=1.8)
    ax.plot([ax_x, ax_x + 4.5], [ax_y - 4, ax_y - 12], color="#222222", lw=1.8)
    ax.text(ax_x, ax_y - 16, "Usuario", ha="center", fontsize=10, fontweight="bold", fontname=FUENTE)

    # Asociaciones del actor: una línea horizontal hasta un tronco vertical y un ramal por caso de uso
    tronco_x = 17
    ys = [nodos[n][1] for n in con_actor]
    ax.plot([ax_x + 5, tronco_x], [ax_y + 3, ax_y + 3], color="#555555", lw=1.2, zorder=1)
    ax.plot([tronco_x, tronco_x], [min(ys + [ax_y + 3]), max(ys + [ax_y + 3])], color="#555555", lw=1.2, zorder=1)
    for n in con_actor:
        x, y, _ = nodos[n]
        borde = (x - A_ELIPSE, y)
        ax.plot([tronco_x, borde[0]], [y, y], color="#555555", lw=1.2, zorder=1)
        malos = segmento_cruza((tronco_x, y), borde, nodos, {n})
        if malos:
            print(f"  AVISO {archivo}: el ramal del actor a {n} cruza {malos}")

    # Relaciones include / extend
    for k, (o, d, tipo) in enumerate(relaciones):
        co, cd = nodos[o][:2], nodos[d][:2]
        p1, p2 = punto_en_elipse(co, cd), punto_en_elipse(cd, co)
        malos = segmento_cruza(p1, p2, nodos, {o, d})
        if malos:
            print(f"  AVISO {archivo}: {tipo} {o}->{d} cruza {malos}")
        ax.annotate("", xy=p2, xytext=p1, zorder=2,
                    arrowprops=dict(arrowstyle="->", linestyle=(0, (5, 3)), color="#444444", lw=1.2))
        frac = 0.5
        mx, my = p1[0] + (p2[0] - p1[0]) * frac, p1[1] + (p2[1] - p1[1]) * frac
        ax.text(mx, my, f"«{tipo}»", fontsize=7.6, ha="center", va="center", zorder=5, fontname=FUENTE,
                bbox=dict(fc="white", ec="none", pad=1.2))

    fig.savefig(os.path.join(SALIDA, archivo + ".png"), facecolor="white")
    plt.close(fig)
    print("diagrama", archivo)


def diagramas_de_casos_de_uso():
    casos_de_uso("casos_ej1", "Ejercicio 1 (6.4, pág. 400) – Diagrama de casos de uso",
        "Sistema: Prueba de excepciones",
        {"p0": (46, 78, "Ejecutar programa de prueba"),
         "p1": (46, 56, "Ver salida del programa"),
         "p2": (46, 34, "Leer explicación del resultado"),
         "p3": (46, 12, "Limpiar salida"),
         "s0": (100, 86, "Ejecutar primer try (división por cero)"),
         "s1": (100, 66, "Ejecutar segundo try (objeto nulo)")},
        ["p0", "p1", "p2", "p3"],
        [("p0", "s0", "include"), ("p0", "s1", "include")])

    casos_de_uso("casos_ej2", "Ejercicio 2 (6.5, pág. 406) – Diagrama de casos de uso",
        "Sistema: Vendedor",
        {"p0": (46, 82, "Ingresar datos del vendedor"),
         "p1": (46, 58, "Crear vendedor"),
         "p2": (46, 34, "Ver datos del vendedor"),
         "p3": (46, 12, "Limpiar formulario"),
         "s0": (96, 74, "Verificar edad"),
         "s1": (96, 50, "Mostrar error de edad inválida"),
         "s2": (96, 24, "Mostrar error de formato de edad")},
        ["p0", "p1", "p2", "p3"],
        [("p1", "s0", "include"), ("s1", "s0", "extend"), ("s2", "p1", "extend")])

    casos_de_uso("casos_ej3", "Ejercicio 3 (6.6, pág. 412) – Diagrama de casos de uso",
        "Sistema: Cálculos numéricos",
        {"p0": (46, 80, "Ingresar valor numérico"),
         "p1": (46, 64, "Calcular logaritmo neperiano"),
         "p2": (46, 44, "Calcular raíz cuadrada"),
         "p3": (86, 54, "Calcular ambos"),
         "p4": (46, 18, "Limpiar resultados"),
         "s0": (111, 84, "Mostrar mensaje de error (valor no válido o no numérico)")},
        ["p0", "p1", "p2", "p3", "p4"],
        [("p3", "p1", "include"), ("p3", "p2", "include"), ("s0", "p1", "extend"), ("s0", "p2", "extend")])

    casos_de_uso("casos_ej4", "Ejercicio 4 (6.7, pág. 418) – Diagrama de casos de uso",
        "Sistema: Equipo de maratón de programación",
        {"p0": (46, 80, "Crear equipo"),
         "p1": (46, 56, "Añadir programador"),
         "p2": (46, 32, "Consultar integrantes"),
         "p3": (46, 10, "Iniciar nuevo equipo"),
         "s0": (96, 66, "Validar nombre y apellidos"),
         "s1": (111, 42, "Mostrar error de validación (dígitos o longitud)"),
         "s2": (96, 20, "Mostrar error de equipo completo"),
         "s3": (96, 88, "Mostrar error de datos obligatorios")},
        ["p0", "p1", "p2", "p3"],
        [("p1", "s0", "include"), ("s1", "s0", "extend"), ("s2", "p1", "extend"), ("s3", "p0", "extend")])

    casos_de_uso("casos_ej5", "Ejercicio 5 (6.8, pág. 427) – Diagrama de casos de uso",
        "Sistema: Lectura de archivos",
        {"p0": (46, 76, "Seleccionar archivo"),
         "p1": (46, 50, "Leer archivo"),
         "p2": (46, 24, "Ver contenido del archivo"),
         "s0": (100, 66, "Abrir flujo de bytes (FileInputStream → BufferedReader)"),
         "s1": (100, 34, "Mostrar error de lectura")},
        ["p0", "p1", "p2"],
        [("p1", "s0", "include"), ("s1", "p1", "extend")])


if __name__ == "__main__":
    diagramas_de_clases()
    diagramas_de_objetos()
    diagramas_de_casos_de_uso()
