import gui.*;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;

/**
 * Herramienta para generar las capturas de pantalla del informe.
 * Abre cada ventana, simula la interacción del usuario y guarda un PNG.
 * Funciona en modo headless (sin pantalla): dibuja cada panel directamente en una imagen.
 * Se ejecuta con: java -Djava.awt.headless=true -cp out:tools-out Capturador docs/capturas
 */
public class Capturador {

    static String carpeta;

    static Component buscar(Container raiz, String nombre) {
        for (Component c : raiz.getComponents()) {
            if (nombre.equals(c.getName())) return c;
            if (c instanceof Container) {
                Component r = buscar((Container) c, nombre);
                if (r != null) return r;
            }
        }
        return null;
    }

    static void ui(Runnable r) throws Exception { SwingUtilities.invokeAndWait(r); }

    static void texto(JPanel f, String nombre, String valor) throws Exception {
        ui(() -> { ((JTextField) buscar(f, nombre)).setText(valor); distribuir(f); });
    }

    static void clic(JPanel f, String nombre) throws Exception {
        ui(() -> { ((AbstractButton) buscar(f, nombre)).doClick(0); distribuir(f); });
    }

    /** Distribuye recursivamente los componentes (no requiere ventana visible). */
    static void distribuir(Component c) {
        if (c instanceof Container) {
            ((Container) c).doLayout();
            for (Component hijo : ((Container) c).getComponents()) distribuir(hijo);
        }
    }

    static JPanel abrir(JPanel p) throws Exception {
        ui(() -> {
            p.setSize(p.getPreferredSize());
            distribuir(p);
        });
        return p;
    }

    static void guardar(JPanel f, String archivo) throws Exception {
        Thread.sleep(250);
        final BufferedImage[] img = new BufferedImage[1];
        ui(() -> {
            distribuir(f);
            Container cp = f;
            int escala = 2;
            img[0] = new BufferedImage(cp.getWidth() * escala, cp.getHeight() * escala, BufferedImage.TYPE_INT_RGB);
            Graphics2D g = img[0].createGraphics();
            g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g.scale(escala, escala);
            cp.paint(g);
            g.dispose();
        });
        ImageIO.write(img[0], "png", new File(carpeta, archivo));
        System.out.println("guardada " + archivo);
    }

    public static void main(String[] args) throws Exception {
        carpeta = args[0];
        new File(carpeta).mkdirs();
        ui(Estilo::instalar);

        JPanel menu = abrir(new PanelMenu());
        guardar(menu, "menu.png");

        // Ejercicio 1
        JPanel f = abrir(new PanelPruebaExcepciones());
        clic(f, "btnEjecutar");
        guardar(f, "ej1_ejecucion.png");

        // Ejercicio 2
        f = abrir(new PanelVendedor());
        texto(f, "txtNombre", "Pedro"); texto(f, "txtApellidos", "Pérez"); texto(f, "txtEdad", "17");
        clic(f, "btnCrear");
        guardar(f, "ej2_error.png");
        texto(f, "txtNombre", "María"); texto(f, "txtApellidos", "López"); texto(f, "txtEdad", "30");
        clic(f, "btnCrear");
        guardar(f, "ej2_correcto.png");

        // Ejercicio 3
        f = abrir(new PanelCalculos());
        texto(f, "txtValor", "25"); clic(f, "btnAmbos");
        guardar(f, "ej3_correcto.png");
        clic(f, "btnLimpiar");
        texto(f, "txtValor", "-4"); clic(f, "btnAmbos");
        texto(f, "txtValor", "abc"); clic(f, "btnAmbos");
        guardar(f, "ej3_errores.png");

        // Ejercicio 4
        f = abrir(new PanelEquipoMaraton());
        texto(f, "txtEquipo", "EquipoUNAL"); texto(f, "txtUniversidad", "Universidad Nacional de Colombia");
        texto(f, "txtLenguaje", "Java"); clic(f, "btnCrearEquipo");
        texto(f, "txtNombre", "Pedro"); texto(f, "txtApellidos", "Pérez"); clic(f, "btnAnadir");
        texto(f, "txtNombre", "Pablo3"); texto(f, "txtApellidos", "Gómez"); clic(f, "btnAnadir");
        guardar(f, "ej4_error_digitos.png");
        texto(f, "txtNombre", "Pablo"); clic(f, "btnAnadir");
        texto(f, "txtNombre", "Ana"); texto(f, "txtApellidos", "Ruiz"); clic(f, "btnAnadir");
        texto(f, "txtNombre", "Luis"); texto(f, "txtApellidos", "Díaz"); clic(f, "btnAnadir");
        guardar(f, "ej4_equipo_completo.png");

        // Ejercicio 5
        f = abrir(new PanelLeerArchivo());
        clic(f, "btnLeer");
        guardar(f, "ej5_correcto.png");
        texto(f, "txtRuta", "noexiste.txt"); clic(f, "btnLeer");
        guardar(f, "ej5_error.png");

        System.exit(0);
    }
}
