#!/bin/sh
# Compila y ejecuta la aplicación (Linux / macOS). Requiere JDK 11 o superior.
mkdir -p out
javac -encoding UTF-8 -d out $(find src -name "*.java") && java -cp out gui.Main
