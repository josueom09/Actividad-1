# Actividad 4 – Programación Orientada a Objetos 2026-2S

Universidad Nacional de Colombia · Docente: Walter Hugo Arboleda Mazo

Interfaz gráfica de usuario (Java Swing) para cinco ejercicios del texto guía
*Ejercicios de Programación Orientada a Objetos con Java y UML* (Leonardo Bermón Angarita), capítulo 6.

| # | Pág. | Ejercicio | Modelo | Interfaz |
|---|------|-----------|--------|----------|
| 1 | 400 | 6.4 Excepciones | `excepciones/PruebaExcepciones` | `gui/PanelPruebaExcepciones` |
| 2 | 406 | 6.5 Lanzamiento de excepciones | `excepciones/Vendedor` | `gui/PanelVendedor` |
| 3 | 412 | 6.6 Catch múltiples | `excepciones/CalculosNumericos` | `gui/PanelCalculos` |
| 4 | 418 | 6.7 Validación de campos | `excepciones/EquipoMaratonProgramacion`, `Programador` | `gui/PanelEquipoMaraton` |
| 5 | 427 | 6.8 Lectura de archivos | `archivos/LeerArchivo` | `gui/PanelLeerArchivo` |

## Ejecutar

Requiere JDK 11 o superior.

- Linux / macOS: `./ejecutar.sh`
- Windows: doble clic en `ejecutar.bat`
- Manual: `javac -encoding UTF-8 -d out $(find src -name "*.java")` y luego `java -cp out gui.Main`

Pruebas del modelo (33 verificaciones):

```
javac -encoding UTF-8 -cp out -d test-out test/Pruebas.java
java -cp out:test-out Pruebas
```

## Estructura

```
src/gui/          interfaces Swing (Main, PanelMenu, Ventana, un Panel por ejercicio)
src/excepciones/  modelo de los ejercicios 1 a 4
src/archivos/     modelo del ejercicio 5
test/             pruebas automáticas
tools/            generación de capturas, diagramas UML e informe PDF
docs/             capturas de pantalla y diagramas (clases, objetos y casos de uso)
prueba.txt        archivo de ejemplo para el ejercicio 5
```

## Capturas

![Menú](docs/capturas/menu.png)

## Subir a GitHub

```
git init
git add .
git commit -m "Actividad 4 - POO 2026-2S"
git branch -M main
git remote add origin https://github.com/TU-USUARIO/actividad4-poo.git
git push -u origin main
```
