import archivos.LeerArchivo;
import excepciones.*;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Pruebas automáticas del modelo (sin JUnit, para no necesitar librerías).
 * Ejecutar con: java -cp out:test-out Pruebas   (desde la raíz del proyecto)
 */
public class Pruebas {

    static int ok = 0, fallos = 0;

    static void verificar(String nombre, boolean condicion) {
        if (condicion) { ok++; System.out.println("  OK     " + nombre); }
        else           { fallos++; System.out.println("  FALLO  " + nombre); }
    }

    static <T extends Throwable> void lanza(String nombre, Class<T> tipo, String contiene, Runnable r) {
        try { r.run(); verificar(nombre + " (no lanzó nada)", false); }
        catch (Throwable t) {
            verificar(nombre, tipo.isInstance(t) && (contiene == null || t.getMessage().contains(contiene)));
        }
    }

    interface Peligroso { void run() throws Exception; }
    static void lanzaEx(String nombre, String contiene, Peligroso r) {
        try { r.run(); verificar(nombre + " (no lanzó nada)", false); }
        catch (Exception e) { verificar(nombre, e.getMessage().contains(contiene)); }
    }

    public static void main(String[] args) throws Exception {
        System.out.println("Ejercicio 1 – PruebaExcepciones");
        List<String> salida = new ArrayList<>();
        PruebaExcepciones.ejecutar(salida::add);
        verificar("salida exacta", salida.equals(List.of(
                "Ingresando al primer try", "División por cero", "Ingresando al primer finally",
                "Ingresando al segundo try", "Ocurrió una excepción", "Ingresando al segundo finally")));

        System.out.println("Ejercicio 2 – Vendedor");
        Vendedor v = new Vendedor("Pedro", "Pérez");
        lanza("17 años → menor de edad", IllegalArgumentException.class, "mayor de 18", () -> v.verificarEdad(17));
        lanza("-5 → rango", IllegalArgumentException.class, "negativa ni mayor a 120", () -> v.verificarEdad(-5));
        lanza("121 → rango", IllegalArgumentException.class, "negativa ni mayor a 120", () -> v.verificarEdad(121));
        v.verificarEdad(18); verificar("18 es válido", v.getEdad() == 18);
        v.verificarEdad(120); verificar("120 es válido", v.getEdad() == 120);
        verificar("imprimir", v.imprimir().contains("Pedro") && v.imprimir().contains("120"));
        lanza("nombre vacío", IllegalArgumentException.class, "obligatorio", () -> new Vendedor(" ", "X"));

        System.out.println("Ejercicio 3 – CalculosNumericos");
        verificar("ln(1) = 0", CalculosNumericos.calcularLogaritmoNeperiano(1) == 0.0);
        verificar("ln(e) = 1", Math.abs(CalculosNumericos.calcularLogaritmoNeperiano(Math.E) - 1) < 1e-12);
        lanza("ln(0)", ArithmeticException.class, "positivo", () -> CalculosNumericos.calcularLogaritmoNeperiano(0));
        lanza("ln(-1)", ArithmeticException.class, "positivo", () -> CalculosNumericos.calcularLogaritmoNeperiano(-1));
        verificar("sqrt(25) = 5", CalculosNumericos.calcularRaizCuadrada(25) == 5.0);
        verificar("sqrt(0) = 0", CalculosNumericos.calcularRaizCuadrada(0) == 0.0);
        lanza("sqrt(-4)", ArithmeticException.class, "negativo", () -> CalculosNumericos.calcularRaizCuadrada(-4));
        verificar("leerValor('3,5') = 3.5", CalculosNumericos.leerValor("3,5") == 3.5);
        verificar("leerValor(' 2.25 ') = 2.25", CalculosNumericos.leerValor(" 2.25 ") == 2.25);
        lanza("leerValor('abc')", NumberFormatException.class, null, () -> CalculosNumericos.leerValor("abc"));
        lanza("leerValor('NaN')", NumberFormatException.class, null, () -> CalculosNumericos.leerValor("NaN"));
        lanza("leerValor('')", NumberFormatException.class, null, () -> CalculosNumericos.leerValor(""));

        System.out.println("Ejercicio 4 – EquipoMaratonProgramacion");
        EquipoMaratonProgramacion eq = new EquipoMaratonProgramacion("EquipoUNAL", "Nacional", "Java");
        verificar("equipo vacío no está lleno", !eq.estaLleno() && !eq.tieneMinimoIntegrantes());
        eq.anadir(new Programador("Pedro", "Pérez"));
        verificar("1 integrante: sin mínimo", !eq.tieneMinimoIntegrantes());
        eq.anadir(new Programador("Pablo", "Gómez"));
        verificar("2 integrantes: mínimo cumplido", eq.tieneMinimoIntegrantes() && !eq.estaLleno());
        eq.anadir(new Programador("Ana", "Ruiz"));
        verificar("3 integrantes: lleno", eq.estaLleno() && eq.getTamanoEquipo() == 3);
        lanzaEx("4.º integrante → equipo completo", "completo", () -> eq.anadir(new Programador("Luis", "Díaz")));
        lanzaEx("nombre con dígito", "dígitos", () -> EquipoMaratonProgramacion.validarCampo("Nombre", "Pablo3"));
        lanzaEx("20 caracteres → inválido", "menos de 20", () -> EquipoMaratonProgramacion.validarCampo("Nombre", "A".repeat(20)));
        EquipoMaratonProgramacion.validarCampo("Nombre", "A".repeat(19)); verificar("19 caracteres es válido", true);
        lanzaEx("campo vacío", "obligatorio", () -> EquipoMaratonProgramacion.validarCampo("Nombre", ""));
        lanza("equipo sin nombre", IllegalArgumentException.class, "obligatorio", () -> new EquipoMaratonProgramacion("", "U", "L"));

        System.out.println("Ejercicio 5 – LeerArchivo");
        String contenido = LeerArchivo.leer("prueba.txt");
        verificar("lee prueba.txt (con tildes)", contenido.contains("Programación Orientada a Objetos"));
        verificar("5 líneas", contenido.split("\n").length == 5);
        try { LeerArchivo.leer("no_existe.txt"); verificar("archivo inexistente", false); }
        catch (IOException e) { verificar("archivo inexistente → IOException", true); }

        System.out.println("\nResultado: " + ok + " correctas, " + fallos + " con fallo");
        if (fallos > 0) System.exit(1);
    }
}
