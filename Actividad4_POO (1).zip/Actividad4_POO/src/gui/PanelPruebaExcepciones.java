package gui;

import excepciones.PruebaExcepciones;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

public class PanelPruebaExcepciones extends JPanel {
    public static final String TITULO = "Ejercicio 1 – Prueba de excepciones";

    private final JTextArea txtSalida = Estilo.areaSalida("txtSalida");
    private final JTextArea txtExplicacion = Estilo.areaSalida("txtExplicacion");

    public PanelPruebaExcepciones() {
        setLayout(new BorderLayout());
        add(Estilo.encabezado("Ejercicio 1 · Excepciones (6.4)",
                "Texto guía, pág. 400 – Clase PruebaExcepciones"), BorderLayout.NORTH);

        txtExplicacion.setFont(txtExplicacion.getFont().deriveFont(Font.PLAIN, 12.5f));
        txtExplicacion.setLineWrap(true);
        txtExplicacion.setWrapStyleWord(true);
        txtExplicacion.setText(
                "Primer bloque try\n"
              + "• 10000/0 es una división entera por cero y lanza ArithmeticException.\n"
              + "• «Después de la división» nunca se ejecuta.\n"
              + "• catch (ArithmeticException) la captura y finally se ejecuta siempre.\n\n"
              + "Segundo bloque try\n"
              + "• objeto.toString() con objeto = null lanza NullPointerException.\n"
              + "• No coincide con catch (ArithmeticException), así que se evalúa el siguiente catch.\n"
              + "• catch (Exception) sí la captura, porque NullPointerException es una Exception.\n"
              + "• «Imprimiendo objeto» nunca se ejecuta y finally se ejecuta siempre.");

        JPanel centro = new JPanel(new GridLayout(1, 2, 12, 0));
        centro.setBorder(new EmptyBorder(14, 14, 6, 14));
        centro.add(Estilo.conScroll(txtSalida, "Salida del programa"));
        centro.add(Estilo.conScroll(txtExplicacion, "¿Por qué se imprime esto?"));
        add(centro, BorderLayout.CENTER);

        JButton btnEjecutar = Estilo.boton("btnEjecutar", "Ejecutar programa");
        JButton btnLimpiar = Estilo.boton("btnLimpiar", "Limpiar");
        btnEjecutar.addActionListener(e -> ejecutar());
        btnLimpiar.addActionListener(e -> txtSalida.setText(""));

        JPanel sur = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10));
        sur.add(btnLimpiar);
        sur.add(btnEjecutar);
        add(sur, BorderLayout.SOUTH);

        setPreferredSize(new Dimension(820, 470));
    }

    private void ejecutar() {
        txtSalida.setText("");
        PruebaExcepciones.ejecutar(linea -> txtSalida.append(linea + "\n"));
    }
}
