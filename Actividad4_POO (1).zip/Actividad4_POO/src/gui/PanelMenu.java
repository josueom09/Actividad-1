package gui;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

public class PanelMenu extends JPanel {
    public static final String TITULO = "Actividad 4 – Programación Orientada a Objetos";

    public PanelMenu() {
        setLayout(new BorderLayout());
        add(Estilo.encabezado("Actividad 4 · Programación Orientada a Objetos",
                "2026-2S – Ejercicios con Java y UML, capítulo 6 (excepciones y archivos)"), BorderLayout.NORTH);

        JPanel opciones = new JPanel(new GridLayout(5, 1, 0, 10));
        opciones.setBorder(new EmptyBorder(16, 18, 16, 18));
        opciones.add(boton("btnEjercicio1", "Ejercicio 1 · pág. 400", "Excepciones: try / catch / finally",
                () -> Ventana.abrir(PanelPruebaExcepciones.TITULO, new PanelPruebaExcepciones())));
        opciones.add(boton("btnEjercicio2", "Ejercicio 2 · pág. 406", "Lanzamiento de excepciones: Vendedor",
                () -> Ventana.abrir(PanelVendedor.TITULO, new PanelVendedor())));
        opciones.add(boton("btnEjercicio3", "Ejercicio 3 · pág. 412", "Catch múltiples: logaritmo y raíz cuadrada",
                () -> Ventana.abrir(PanelCalculos.TITULO, new PanelCalculos())));
        opciones.add(boton("btnEjercicio4", "Ejercicio 4 · pág. 418", "Validación de campos: equipo de maratón",
                () -> Ventana.abrir(PanelEquipoMaraton.TITULO, new PanelEquipoMaraton())));
        opciones.add(boton("btnEjercicio5", "Ejercicio 5 · pág. 427", "Lectura de archivos de texto",
                () -> Ventana.abrir(PanelLeerArchivo.TITULO, new PanelLeerArchivo())));
        add(opciones, BorderLayout.CENTER);

        setPreferredSize(new Dimension(520, 470));
    }

    private JButton boton(String nombre, String titulo, String descripcion, Runnable abrir) {
        JButton boton = new JButton("<html><b>" + titulo + "</b><br>" + descripcion + "</html>");
        boton.setName(nombre);
        boton.setHorizontalAlignment(SwingConstants.LEFT);
        boton.addActionListener(e -> abrir.run());
        return boton;
    }
}
