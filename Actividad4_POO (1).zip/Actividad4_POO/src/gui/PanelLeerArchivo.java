package gui;

import archivos.LeerArchivo;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.*;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;

public class PanelLeerArchivo extends JPanel {
    public static final String TITULO = "Ejercicio 5 – Lectura de archivos";

    private final JTextField txtRuta = Estilo.campo("txtRuta", 30);
    private final JLabel lblEstado = new JLabel(" ");
    private final JTextArea txtSalida = Estilo.areaSalida("txtSalida");

    public PanelLeerArchivo() {
        setLayout(new BorderLayout());
        add(Estilo.encabezado("Ejercicio 5 · Lectura de archivos (6.8)",
                "Texto guía, pág. 427 – Clase LeerArchivo"), BorderLayout.NORTH);

        txtRuta.setText("prueba.txt");
        JButton btnExaminar = Estilo.boton("btnExaminar", "Examinar...");
        JButton btnLeer = Estilo.boton("btnLeer", "Leer archivo");
        btnExaminar.addActionListener(e -> examinar());
        btnLeer.addActionListener(e -> leer());

        JPanel seleccion = new JPanel(new BorderLayout(8, 0));
        seleccion.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createTitledBorder("Archivo de texto"), new EmptyBorder(4, 8, 6, 8)));
        seleccion.add(txtRuta, BorderLayout.CENTER);
        JPanel botones = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        botones.add(btnExaminar);
        botones.add(btnLeer);
        seleccion.add(botones, BorderLayout.EAST);

        lblEstado.setName("lblEstado");
        lblEstado.setBorder(new EmptyBorder(4, 4, 4, 4));
        JPanel norte = new JPanel(new BorderLayout());
        norte.add(seleccion, BorderLayout.NORTH);
        norte.add(lblEstado, BorderLayout.SOUTH);

        JPanel centro = new JPanel(new BorderLayout(0, 6));
        centro.setBorder(new EmptyBorder(14, 14, 14, 14));
        centro.add(norte, BorderLayout.NORTH);
        centro.add(Estilo.conScroll(txtSalida, "Contenido del archivo"), BorderLayout.CENTER);
        add(centro, BorderLayout.CENTER);

        setPreferredSize(new Dimension(680, 480));
    }

    private void examinar() {
        JFileChooser selector = new JFileChooser(new File("."));
        selector.setFileFilter(new FileNameExtensionFilter("Archivos de texto (*.txt)", "txt"));
        if (selector.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
            txtRuta.setText(selector.getSelectedFile().getPath());
            leer();
        }
    }

    private void leer() {
        String ruta = txtRuta.getText().trim();
        try {
            String contenido = LeerArchivo.leer(ruta);
            txtSalida.setText(contenido);
            txtSalida.setCaretPosition(0);
            long lineas = contenido.chars().filter(ch -> ch == '\n').count();
            Estilo.estado(lblEstado, "Archivo leído correctamente (" + lineas + " líneas).", false);
        } catch (IOException e) {
            txtSalida.setText("");
            String detalle = (e instanceof FileNotFoundException)
                    ? "el archivo «" + ruta + "» no existe o no se puede abrir."
                    : e.getMessage();
            Estilo.estado(lblEstado, "No se pudo leer el archivo.\nDetalle: " + detalle, true);
        }
    }
}
