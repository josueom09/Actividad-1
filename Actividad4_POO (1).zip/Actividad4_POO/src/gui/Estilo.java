package gui;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

public final class Estilo {
    public static final Color VERDE = new Color(0x1B6B52);
    public static final Color OK = new Color(0x1E7B34);
    public static final Color ERROR = new Color(0xB3261E);

    private Estilo() {
    }

    public static void instalar() {
        try {
            UIManager.put("nimbusBase", VERDE);
            UIManager.put("nimbusFocus", VERDE);
            UIManager.put("nimbusSelectionBackground", VERDE);
            for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (Exception e) {
        }
    }

    public static JPanel encabezado(String titulo, String subtitulo) {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBackground(VERDE);
        panel.setBorder(new EmptyBorder(12, 18, 12, 18));

        JLabel t = new JLabel(titulo);
        t.setForeground(Color.WHITE);
        t.setFont(t.getFont().deriveFont(Font.BOLD, 18f));
        t.setBorder(new EmptyBorder(0, 0, 0, 12));
        JLabel s = new JLabel(subtitulo);
        s.setForeground(new Color(0xD7EBE3));
        s.setFont(s.getFont().deriveFont(Font.PLAIN, 12f));
        s.setBorder(new EmptyBorder(0, 0, 0, 12));

        panel.add(t);
        panel.add(Box.createVerticalStrut(2));
        panel.add(s);
        return panel;
    }

    public static JTextArea areaSalida(String nombre) {
        JTextArea area = new JTextArea();
        area.setName(nombre);
        area.setEditable(false);
        area.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 13));
        area.setBackground(Color.WHITE);
        area.setMargin(new Insets(6, 8, 6, 8));
        return area;
    }

    public static JScrollPane conScroll(JTextArea area, String titulo) {
        JScrollPane sp = new JScrollPane(area);
        sp.setBorder(BorderFactory.createTitledBorder(titulo));
        return sp;
    }

    public static void estado(JLabel etiqueta, String texto, boolean error) {
        etiqueta.setForeground(error ? ERROR : OK);
        etiqueta.setText("<html>" + texto.replace("\n", "<br>") + "</html>");
    }

    public static void fila(JPanel panel, int y, String etiqueta, JComponent campo) {
        GridBagConstraints c = new GridBagConstraints();
        c.gridx = 0;
        c.gridy = y;
        c.anchor = GridBagConstraints.WEST;
        c.insets = new Insets(5, 0, 5, 12);
        JLabel rotulo = new JLabel(etiqueta);
        rotulo.setBorder(new EmptyBorder(0, 0, 0, 6));
        panel.add(rotulo, c);

        c.gridx = 1;
        c.weightx = 1;
        c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(5, 0, 5, 0);
        panel.add(campo, c);
    }

    public static JTextField campo(String nombre, int columnas) {
        JTextField campo = new JTextField(columnas);
        campo.setName(nombre);
        return campo;
    }

    public static JButton boton(String nombre, String texto) {
        JButton boton = new JButton(texto);
        boton.setName(nombre);
        return boton;
    }
}
