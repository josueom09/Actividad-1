package gui;

import javax.swing.JFrame;
import javax.swing.SwingUtilities;

public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            Estilo.instalar();
            new Ventana(PanelMenu.TITULO, new PanelMenu(), JFrame.EXIT_ON_CLOSE).setVisible(true);
        });
    }
}
