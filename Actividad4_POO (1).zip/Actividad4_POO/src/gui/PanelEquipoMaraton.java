package gui;

import excepciones.EquipoMaratonProgramacion;
import excepciones.Programador;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class PanelEquipoMaraton extends JPanel {
    public static final String TITULO = "Ejercicio 4 – Equipo de maratón de programación";

    private final JTextField txtEquipo = Estilo.campo("txtEquipo", 22);
    private final JTextField txtUniversidad = Estilo.campo("txtUniversidad", 22);
    private final JTextField txtLenguaje = Estilo.campo("txtLenguaje", 22);
    private final JButton btnCrearEquipo = Estilo.boton("btnCrearEquipo", "Crear equipo");

    private final JTextField txtNombre = Estilo.campo("txtNombre", 22);
    private final JTextField txtApellidos = Estilo.campo("txtApellidos", 22);
    private final JButton btnAnadir = Estilo.boton("btnAnadir", "Añadir programador");
    private final JLabel lblContador = new JLabel("Primero cree el equipo.");

    private final DefaultTableModel modeloTabla =
            new DefaultTableModel(new Object[]{"#", "Nombre", "Apellidos"}, 0) {
                @Override
                public boolean isCellEditable(int fila, int columna) {
                    return false;
                }
            };
    private final JLabel lblEstado = new JLabel(" ");

    private EquipoMaratonProgramacion equipo;

    public PanelEquipoMaraton() {
        setLayout(new BorderLayout());
        add(Estilo.encabezado("Ejercicio 4 · Validación de campos (6.7)",
                "Texto guía, pág. 418 – Clases EquipoMaratonProgramacion y Programador"), BorderLayout.NORTH);

        JPanel datosEquipo = new JPanel(new GridBagLayout());
        datosEquipo.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createTitledBorder("1. Datos del equipo"), new EmptyBorder(2, 10, 6, 10)));
        Estilo.fila(datosEquipo, 0, "Nombre del equipo:", txtEquipo);
        Estilo.fila(datosEquipo, 1, "Universidad:", txtUniversidad);
        Estilo.fila(datosEquipo, 2, "Lenguaje de programación:", txtLenguaje);
        JButton btnNuevo = Estilo.boton("btnNuevo", "Nuevo equipo");
        btnCrearEquipo.addActionListener(e -> crearEquipo());
        btnNuevo.addActionListener(e -> nuevoEquipo());
        JPanel botonesEquipo = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        botonesEquipo.add(btnNuevo);
        botonesEquipo.add(btnCrearEquipo);
        GridBagConstraints c = new GridBagConstraints();
        c.gridx = 0; c.gridy = 3; c.gridwidth = 2; c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(4, 0, 0, 0);
        datosEquipo.add(botonesEquipo, c);

        JPanel integrantes = new JPanel(new BorderLayout(0, 6));
        integrantes.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createTitledBorder("2. Integrantes (mínimo 2, máximo 3)"), new EmptyBorder(2, 10, 8, 10)));
        JPanel formProg = new JPanel(new GridBagLayout());
        Estilo.fila(formProg, 0, "Nombre:", txtNombre);
        Estilo.fila(formProg, 1, "Apellidos:", txtApellidos);
        btnAnadir.setEnabled(false);
        btnAnadir.addActionListener(e -> anadirProgramador());
        JPanel botonAnadir = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 0));
        botonAnadir.add(btnAnadir);
        JPanel norteInt = new JPanel(new BorderLayout(0, 4));
        norteInt.add(formProg, BorderLayout.NORTH);
        norteInt.add(botonAnadir, BorderLayout.CENTER);
        lblContador.setName("lblContador");
        lblContador.setFont(lblContador.getFont().deriveFont(Font.BOLD));
        norteInt.add(lblContador, BorderLayout.SOUTH);

        JTable tabla = new JTable(modeloTabla);
        tabla.setName("tblIntegrantes");
        tabla.setRowHeight(24);
        tabla.getColumnModel().getColumn(0).setMaxWidth(40);
        JScrollPane scrollTabla = new JScrollPane(tabla);
        scrollTabla.setColumnHeaderView(tabla.getTableHeader());
        scrollTabla.setPreferredSize(new Dimension(100, 105));
        integrantes.add(norteInt, BorderLayout.NORTH);
        integrantes.add(scrollTabla, BorderLayout.CENTER);

        lblEstado.setName("lblEstado");
        lblEstado.setBorder(new EmptyBorder(2, 6, 2, 6));
        lblEstado.setPreferredSize(new Dimension(100, 40));

        JPanel centro = new JPanel(new BorderLayout(0, 8));
        centro.setBorder(new EmptyBorder(12, 14, 8, 14));
        JPanel pila = new JPanel(new BorderLayout(0, 8));
        pila.add(datosEquipo, BorderLayout.NORTH);
        pila.add(integrantes, BorderLayout.CENTER);
        centro.add(pila, BorderLayout.CENTER);
        centro.add(lblEstado, BorderLayout.SOUTH);
        add(centro, BorderLayout.CENTER);

        setPreferredSize(new Dimension(640, 640));
    }

    private void crearEquipo() {
        try {
            equipo = new EquipoMaratonProgramacion(
                    txtEquipo.getText(), txtUniversidad.getText(), txtLenguaje.getText());
            txtEquipo.setEnabled(false);
            txtUniversidad.setEnabled(false);
            txtLenguaje.setEnabled(false);
            btnCrearEquipo.setEnabled(false);
            btnAnadir.setEnabled(true);
            actualizarContador();
            Estilo.estado(lblEstado, "Equipo «" + equipo.getNombreEquipo()
                    + "» creado. Añada de 2 a 3 integrantes.", false);
        } catch (IllegalArgumentException e) {
            Estilo.estado(lblEstado, "Error: " + e.getMessage(), true);
        }
    }

    private void anadirProgramador() {
        if (equipo == null) {
            return;
        }
        try {
            String nombre = txtNombre.getText().trim();
            String apellidos = txtApellidos.getText().trim();
            EquipoMaratonProgramacion.validarCampo("Nombre", nombre);
            EquipoMaratonProgramacion.validarCampo("Apellidos", apellidos);
            equipo.anadir(new Programador(nombre, apellidos));

            modeloTabla.addRow(new Object[]{equipo.getTamanoEquipo(), nombre, apellidos});
            txtNombre.setText("");
            txtApellidos.setText("");
            txtNombre.requestFocusInWindow();
            actualizarContador();
            Estilo.estado(lblEstado, "Programador «" + nombre + " " + apellidos + "» añadido al equipo.", false);
        } catch (Exception e) {
            Estilo.estado(lblEstado, "Excepción: " + e.getMessage(), true);
        }
    }

    private void actualizarContador() {
        int n = equipo.getTamanoEquipo();
        String situacion;
        if (equipo.estaLleno()) {
            situacion = "equipo completo";
        } else if (equipo.tieneMinimoIntegrantes()) {
            situacion = "mínimo cumplido, aún puede añadir uno más";
        } else {
            situacion = "faltan integrantes para el mínimo de " + EquipoMaratonProgramacion.MINIMO_INTEGRANTES;
        }
        lblContador.setText("Integrantes: " + n + "/" + EquipoMaratonProgramacion.MAXIMO_INTEGRANTES
                + " · " + situacion);
    }

    private void nuevoEquipo() {
        equipo = null;
        modeloTabla.setRowCount(0);
        for (JTextField campo : new JTextField[]{txtEquipo, txtUniversidad, txtLenguaje, txtNombre, txtApellidos}) {
            campo.setText("");
        }
        txtEquipo.setEnabled(true);
        txtUniversidad.setEnabled(true);
        txtLenguaje.setEnabled(true);
        btnCrearEquipo.setEnabled(true);
        btnAnadir.setEnabled(false);
        lblContador.setText("Primero cree el equipo.");
        lblEstado.setText(" ");
    }
}
