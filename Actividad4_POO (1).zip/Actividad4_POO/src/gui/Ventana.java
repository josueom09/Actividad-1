package gui;

import javax.swing.JFrame;
import javax.swing.JPanel;

public class Ventana extends JFrame {
    public Ventana(String titulo, JPanel contenido, int cierre) {
        super(titulo);
        setDefaultCloseOperation(cierre);
        setContentPane(contenido);
        pack();
        setLocationRelativeTo(null);
    }

    public static void abrir(String titulo, JPanel contenido) {
        new Ventana(titulo, contenido, DISPOSE_ON_CLOSE).setVisible(true);
    }
}
