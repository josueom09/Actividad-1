package excepciones;

public class CalculosNumericos {
    private CalculosNumericos() {
    }

    public static double calcularLogaritmoNeperiano(double valor) {
        if (valor <= 0) {
            throw new ArithmeticException("El valor debe ser un número positivo para calcular el logaritmo.");
        }
        return Math.log(valor);
    }

    public static double calcularRaizCuadrada(double valor) {
        if (valor < 0) {
            throw new ArithmeticException("El valor no puede ser negativo para calcular la raíz cuadrada.");
        }
        return Math.sqrt(valor);
    }

    public static double leerValor(String texto) {
        if (texto == null || texto.isBlank()) {
            throw new NumberFormatException("Valor vacío");
        }
        double valor = Double.parseDouble(texto.trim().replace(',', '.'));
        if (Double.isNaN(valor) || Double.isInfinite(valor)) {
            throw new NumberFormatException("Valor no finito");
        }
        return valor;
    }
}
