package excepciones;

import java.util.function.Consumer;

public class PruebaExcepciones {
    private PruebaExcepciones() {
    }

    public static void ejecutar(Consumer<String> salida) {
        try {
            salida.accept("Ingresando al primer try");
            double cociente = 10000 / 0;
            salida.accept("Después de la división");
        } catch (ArithmeticException e) {
            salida.accept("División por cero");
        } finally {
            salida.accept("Ingresando al primer finally");
        }

        try {
            salida.accept("Ingresando al segundo try");
            Object objeto = null;
            objeto.toString();
            salida.accept("Imprimiendo objeto");
        } catch (ArithmeticException e) {
            salida.accept("División por cero");
        } catch (Exception e) {
            salida.accept("Ocurrió una excepción");
        } finally {
            salida.accept("Ingresando al segundo finally");
        }
    }
}
