package excepciones;

public class Programador {
    private final String nombre;
    private final String apellidos;

    public Programador(String nombre, String apellidos) {
        this.nombre = nombre;
        this.apellidos = apellidos;
    }

    public String getNombre()    { return nombre; }
    public String getApellidos() { return apellidos; }
}
