package excepciones;

public class Vendedor {
    public static final int EDAD_MINIMA = 18;
    public static final int EDAD_MAXIMA = 120;

    private final String nombre;
    private final String apellidos;
    private int edad;

    public Vendedor(String nombre, String apellidos) {
        if (nombre == null || nombre.isBlank()) {
            throw new IllegalArgumentException("El nombre del vendedor es obligatorio.");
        }
        if (apellidos == null || apellidos.isBlank()) {
            throw new IllegalArgumentException("Los apellidos del vendedor son obligatorios.");
        }
        this.nombre = nombre.trim();
        this.apellidos = apellidos.trim();
    }

    public void verificarEdad(int edad) {
        if (edad < 0 || edad > EDAD_MAXIMA) {
            throw new IllegalArgumentException("La edad no puede ser negativa ni mayor a " + EDAD_MAXIMA + ".");
        }
        if (edad < EDAD_MINIMA) {
            throw new IllegalArgumentException("El vendedor debe ser mayor de " + EDAD_MINIMA + " años.");
        }
        this.edad = edad;
    }

    public String imprimir() {
        return "Nombre del vendedor = " + nombre + "\n"
             + "Apellidos del vendedor = " + apellidos + "\n"
             + "Edad del vendedor = " + edad;
    }

    public String getNombre()    { return nombre; }
    public String getApellidos() { return apellidos; }
    public int getEdad()         { return edad; }
}
