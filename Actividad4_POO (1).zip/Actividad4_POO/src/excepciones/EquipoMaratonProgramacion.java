package excepciones;

public class EquipoMaratonProgramacion {
    public static final int MINIMO_INTEGRANTES = 2;
    public static final int MAXIMO_INTEGRANTES = 3;

    public static final int LONGITUD_LIMITE = 20;

    private final String nombreEquipo;
    private final String universidad;
    private final String lenguajeProgramacion;
    private final Programador[] programadores;
    private int tamanoEquipo;

    public EquipoMaratonProgramacion(String nombreEquipo, String universidad, String lenguajeProgramacion) {
        exigir(nombreEquipo, "El nombre del equipo es obligatorio.");
        exigir(universidad, "La universidad es obligatoria.");
        exigir(lenguajeProgramacion, "El lenguaje de programación es obligatorio.");
        this.nombreEquipo = nombreEquipo.trim();
        this.universidad = universidad.trim();
        this.lenguajeProgramacion = lenguajeProgramacion.trim();
        this.programadores = new Programador[MAXIMO_INTEGRANTES];
        this.tamanoEquipo = 0;
    }

    private static void exigir(String valor, String mensaje) {
        if (valor == null || valor.isBlank()) {
            throw new IllegalArgumentException(mensaje);
        }
    }

    public boolean estaLleno() {
        return tamanoEquipo == programadores.length;
    }

    public boolean tieneMinimoIntegrantes() {
        return tamanoEquipo >= MINIMO_INTEGRANTES;
    }

    public void anadir(Programador programador) throws Exception {
        if (estaLleno()) {
            throw new Exception("El equipo está completo. No se pudo agregar programador.");
        }
        programadores[tamanoEquipo] = programador;
        tamanoEquipo++;
    }

    public static void validarCampo(String etiqueta, String campo) throws Exception {
        if (campo == null || campo.isBlank()) {
            throw new Exception("El campo " + etiqueta + " es obligatorio.");
        }
        for (int j = 0; j < campo.length(); j++) {
            char c = campo.charAt(j);
            if (Character.isDigit(c)) {
                throw new Exception("El campo " + etiqueta + " no puede tener dígitos.");
            }
        }
        if (campo.length() >= LONGITUD_LIMITE) {
            throw new Exception("El campo " + etiqueta + " debe tener menos de "
                    + LONGITUD_LIMITE + " caracteres.");
        }
    }

    public String getNombreEquipo()          { return nombreEquipo; }
    public String getUniversidad()           { return universidad; }
    public String getLenguajeProgramacion()  { return lenguajeProgramacion; }
    public int getTamanoEquipo()             { return tamanoEquipo; }

    public Programador getProgramador(int i) { return programadores[i]; }
}
